package model;

import com.sun.jna.platform.win32.WinDef.HWND;

public class Window {
	private final HWND mfHandle;
	private final String mfTitle;
	
	public Window(HWND handle, String title) {
		mfHandle = handle;
		mfTitle = title;
	}

	public HWND getHandle() {
		return mfHandle;
	}

	public String getTitle() {
		return mfTitle;
	}
}
