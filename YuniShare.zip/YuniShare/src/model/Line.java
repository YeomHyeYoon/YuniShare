package model;

import java.awt.Point;
import java.io.Serializable;
import java.util.Vector;

public class Line implements Serializable {
	
	
	private final Vector<Point> vPointer;
	
	public Line( Vector<Point> point) {
		vPointer = point;
	}

	public Vector<Point> getvPointer() {
		return vPointer;
	}

	
}
