package model;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.imageio.ImageIO;

import controller.App;

public class Packet implements Serializable {

	private String mSerializedLines = null;
	private BufferedImage mCapturedWindowImage = null;

	public Packet(
			String noteContent,
			BufferedImage capturedWindowImage) {
		//		super();
		mSerializedLines = noteContent;
		mCapturedWindowImage = capturedWindowImage;
	}

	// ��ü�Է�
	private void writeObject(ObjectOutputStream objectOutputStream) throws IOException{
		objectOutputStream.writeObject(mSerializedLines);
		ImageIO.write(mCapturedWindowImage, App.IMAGE_TYPE, ImageIO.createImageOutputStream(objectOutputStream));
	}

	//��ü �о����
	private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException{
		mSerializedLines = (String) objectInputStream.readObject();
		mCapturedWindowImage = ImageIO.read(ImageIO.createImageInputStream(objectInputStream));
	}

	public String getSerializedLines() {
		return mSerializedLines;
	}

	public BufferedImage getCapturedWindowImage() {
		return mCapturedWindowImage;
	}
}
