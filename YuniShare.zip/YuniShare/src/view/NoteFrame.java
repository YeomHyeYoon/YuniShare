package view;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Queue;
import java.util.Vector;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.swing.JFrame;
import model.Line;

public abstract class NoteFrame extends JFrame implements MouseListener, MouseMotionListener {
	
	
	public abstract void onMouseDragged(Line line);
	public abstract void onWindowClosing();
	
	private boolean mfIsHost;
	private Vector<Point> vStart = new Vector<Point>();
	private final Queue<Line> mfLines;
	
	
	public NoteFrame(boolean isHost, String address) {
		setTitle("Note - " + (isHost ? "Host" : "Guest") + " [" + address + "]");
		
		mfIsHost = isHost;
		mfLines = new ConcurrentLinkedQueue<>();

		
		// ȭ����� 
		setAlwaysOnTop(true);
		
		final Dimension screenDimension = Toolkit.getDefaultToolkit().getScreenSize();
		final int size = 480;
		
		setSize(size, size);
		setResizable(false);
		setLocation(screenDimension.width - size, screenDimension.height - size);

		//���̾ƿ� �ʱ�ȭ 
		setLayout(new BorderLayout());
		

		// ������ ���� 
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				super.windowClosing(e);
				onWindowClosing();
			}
		});
		
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	
	@Override
	public void paint(Graphics g) {
		
		// ���� ���� 
		 g.setColor(Color.RED); 

		 
		 //Guest�� ���� �޾ƿ� ������
		 	for (Line line : mfLines) {
		 		for (int i = 1; i < line.getvPointer().size(); i++) {
				    if (line.getvPointer().get(i - 1) == null)
				     continue;
				    else if (line.getvPointer().get(i) == null)
				     continue;
				    else
				     g.drawLine((int)line.getvPointer().get(i - 1).getX(), (int) line.getvPointer().get(i - 1).getY(),
				       (int) line.getvPointer().get(i).getX(), (int) line.getvPointer().get(i).getY());
				   }
			}


		 	
		 	
		 
		   for (int i = 1; i < vStart.size(); i++) {
		    if (vStart.get(i - 1) == null)
		     continue;
		    else if (vStart.get(i) == null)
		     continue;
		    else
		     g.drawLine((int) vStart.get(i - 1).getX(), (int) vStart.get(i - 1).getY(),
		       (int) vStart.get(i).getX(), (int) vStart.get(i).getY());
		   }

	}
	
	

	@Override
	public void mousePressed(MouseEvent event) {
		 vStart.add(null);
	     vStart.add(event.getPoint());
	    
	     
	}
	
	@Override
	public void mouseReleased(MouseEvent event) {
		
	}
	
	@Override
	public void mouseEntered(MouseEvent event) {
		
	}

	@Override
	public void mouseExited(MouseEvent event) {
	
	}
	
	@Override
	public void mouseDragged(MouseEvent event) {
		 vStart.add(event.getPoint());
	     repaint();
	     
	     Line line = new Line(vStart);
			
	     if (mfIsHost) {
				mfLines.add(line);
			} else {
				onMouseDragged(line);
			}

	}
	
	@Override
	public void mouseMoved(MouseEvent event) {

	}
	
	@Override
	public void mouseClicked(MouseEvent event) {
	}

	public void addLine(Line line) {
		mfLines.add(line);
		repaint();
	}

	public Queue<Line> getLines() {
		return mfLines;
	}

	public void setLines(Queue<Line> lines) {
		mfLines.clear();
		mfLines.addAll(lines);
		repaint();
	}
}