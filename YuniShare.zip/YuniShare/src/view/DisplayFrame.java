package view;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public abstract class DisplayFrame extends JFrame {
	
	public abstract void onWindowClosing();
	
	private BufferedImage mCapturedWindowImage = null;
	
	public DisplayFrame() {
		setTitle("Display");
		
		//â ����
		final Dimension screenDimension = Toolkit.getDefaultToolkit().getScreenSize();
		final int height = screenDimension.height;
		final int width = height;
		setSize(width, height);
		
		
		setLayout(new BorderLayout());
		
		//â ���� ��ư �̺�Ʈ
        addWindowListener(new WindowAdapter() {
        	@Override
        	public void windowClosing(WindowEvent e) {
        		super.windowClosing(e);
        		onWindowClosing();
        	}
		});
	}
	

	@Override
	public void paint(Graphics g) {
//		super.paint(g);
		if (mCapturedWindowImage != null) {
			g.drawImage(mCapturedWindowImage, 0, 0, this);
		}
	}
	
	@Override
	public void update(Graphics g) {
		paint(g);
	}
	
	//�޾ƿ� ȭ�� ����
	public void draw(BufferedImage capturedWindowImage) {
		if (capturedWindowImage != null) {
			mCapturedWindowImage = capturedWindowImage;
			repaint();
		}
	}
}
