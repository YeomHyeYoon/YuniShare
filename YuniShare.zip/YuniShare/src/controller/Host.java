package controller;

import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import com.google.gson.Gson;
import com.sun.jna.platform.win32.GDI32Util;

import controller.App.User32;
import model.Line;
import model.Packet;
import model.Window;
import view.DisplayFrame;
import view.MenuFrame;
import view.NoteFrame;

public class Host {
	
	private final User32 mfUser32;
	private final Window mfWindow;
	
	// ������ ȭ�� ĸ��
	
	private BufferedImage mCapturedWindowImage = null;
	
	private final Capturer mfCapturer;
	private final ScheduledExecutorService mfWindowCaptureExecutor;
	
	private class Capturer implements Runnable {
		
		@Override
		public void run() {
			mCapturedWindowImage = GDI32Util.getScreenshot(mfWindow.getHandle());
		}
	}
	
	// ���� Accepter
	
	private ServerSocket mfServerSocket;
	private final Map<String, Socket> mfClientSockets;
	
	private final Accepter mfAccepter;
	private final ExecutorService mfAcceptExecutor;
	private class Accepter implements Runnable {
		
		private Accepter() {
		}

		@Override
		public void run() {
			while(true){
				try {
					Socket socket = mfServerSocket.accept();
					BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
					
					if (mfClientSockets.size() < App.MAX_GUEST) {
						//��� ��ȿ�� ǥ��
						writer.write("valid\n");
						writer.flush();
						mfClientSockets.put(
								socket.getRemoteSocketAddress().toString().replace("/", ""),
								socket);						
					} else {
						writer.write("invalid\n");
						writer.flush();
						socket.close();
					}
				} catch (IOException e) {
					continue;
				}
			}
		}
	}
	
	// Sender
	
	private final Sender mfSender;
	private final ScheduledExecutorService mfSendExecutor;
	private class Sender implements Runnable {
		
		private Sender() {
		}

		@Override
		public void run() {
			
			BufferedImage capturedWindowImage = mCapturedWindowImage;
			for (Socket socket : mfClientSockets.values()) {
				try {
					OutputStream outputStream = socket.getOutputStream();
					ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
					
					//��ü�� ������ JSON �������� ����
					objectOutputStream.writeObject(new Packet(new Gson().toJson(mfNoteFrame.getLines()), capturedWindowImage));
					
					objectOutputStream.flush();
				} catch (IOException e) {
					mfClientSockets.remove(socket.getRemoteSocketAddress().toString().replace("/", ""));
				}
				
//				try {
//					OutputStream outputStream = socket.getOutputStream();
//					ImageIO.write(capturedWindowImage, App.IMAGE_TYPE, new BufferedOutputStream(outputStream));
//					outputStream.flush();
//				} catch (IOException e) {
//				}
			}
		}
	}
	
	private final Receiver mfReceiver;
	private final ExecutorService mfReceiveExecutor;
	private class Receiver implements Runnable {
		@Override
		public void run() {
			while (true) {
				for (Socket socket : mfClientSockets.values()) {
					try {
						InputStream inputStream = socket.getInputStream();
						
						// ���� �� �ִ°��� �����ϸ�
						if (inputStream.available() > 0) {
							ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
							
							Line line = (Line) objectInputStream.readObject();
							
							if (line != null) {
								mfNoteFrame.addLine(line);
							}
						}
						
					} catch (IOException e) {
						mfClientSockets.remove(socket.getRemoteSocketAddress().toString().replace("/", ""));
					} catch (ClassNotFoundException e) {
						mfClientSockets.remove(socket.getRemoteSocketAddress().toString().replace("/", ""));
					}
				}
			}
		}
	}
	
	private final NoteFrame mfNoteFrame;
	
	public Host(final User32 user32, final Window window) throws IOException {
		mfUser32 = user32;
		mfWindow = window;
		
		mfWindowCaptureExecutor = Executors.newSingleThreadScheduledExecutor();
		mfWindowCaptureExecutor.scheduleAtFixedRate(mfCapturer = new Capturer(), 0, 83320, TimeUnit.MICROSECONDS);
		
		mfServerSocket = new ServerSocket(0);
		mfClientSockets = new ConcurrentHashMap<>();
		mfAcceptExecutor = Executors.newSingleThreadExecutor();
		mfAcceptExecutor.execute(mfAccepter = new Accepter());
		
		mfSendExecutor = Executors.newSingleThreadScheduledExecutor();
		mfSendExecutor.scheduleAtFixedRate(mfSender = new Sender(), 0, 83320, TimeUnit.MICROSECONDS);
		
		mfReceiveExecutor = Executors.newSingleThreadExecutor();
		mfReceiveExecutor.execute(mfReceiver = new Receiver());
		
		mfNoteFrame = new NoteFrame(true, mfServerSocket.getInetAddress().getHostAddress() + ":" + mfServerSocket.getLocalPort()) {
			

			@Override
			public void onMouseDragged(Line line) {
			}

			@Override
			public void onWindowClosing() {
				
				mfWindowCaptureExecutor.shutdown();
				mfAcceptExecutor.shutdown();
				mfSendExecutor.shutdown();
				mfReceiveExecutor.shutdown();
				
				try {
					mfServerSocket.close();
				} catch (IOException e) {
				}
				
				for (Socket socket : mfClientSockets.values()) {
					try {
						socket.close();
					} catch (IOException e) {
					}
				}
				
				new MenuFrame(mfUser32).setVisible(true);
			}
		};
		mfNoteFrame.setVisible(true);
	}
}
