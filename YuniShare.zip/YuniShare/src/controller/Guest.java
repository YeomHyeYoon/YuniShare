package controller;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import controller.App.User32;
import model.Line;
import model.Packet;
import view.DisplayFrame;
import view.MenuFrame;
import view.NoteFrame;

public class Guest {
	
	private final String mfAddress;
	
	private final DisplayFrame mfDisplayFrame;
	
	private boolean mIsDisconnecting = false;
	private final User32 mfUser32;
	private final NoteFrame mfNoteFrame;
	
	private final Receiver mfReceiver;
	private final Socket mfSocket;
	private final ExecutorService mfReceiverExecutor;
	private class Receiver implements Runnable {
		
		private Receiver() {
		}

		@Override
		public void run() {
			while (true) {
				try {
//					BufferedImage capturedWindowImage = ImageIO.read(new BufferedInputStream(mfInputStream));
//					if (capturedWindowImage != null) {
//						mfDisplayFrame.draw(capturedWindowImage);
//					}
					
					ObjectInputStream objectInputStream = new ObjectInputStream(mfSocket.getInputStream());
					Packet packet = (Packet) objectInputStream.readObject();
					
					if (packet.getCapturedWindowImage() != null) {
						mfDisplayFrame.draw(packet.getCapturedWindowImage());
					}
					
					mfNoteFrame.setLines(new Gson().fromJson(packet.getSerializedLines(), new TypeToken<Queue<Line>>() {}.getType()));
				} catch (IOException e1) {
					System.out.println("error0");
					e1.printStackTrace();
					break;
				} catch (ClassNotFoundException e) {
					System.out.println("error1");
					e.printStackTrace();
					break;
				}
			}
			onDisconnected(0);
		}
	}
	

	
	public Guest(final User32 user32, final String address, final Socket socket) throws UnknownHostException, IOException {
		mfUser32 = user32;
		mfSocket = socket;
		mfAddress = address;

		mfReceiverExecutor = Executors.newSingleThreadScheduledExecutor();
		mfReceiverExecutor.execute(mfReceiver = new Receiver());

		mfDisplayFrame = new DisplayFrame() {
			@Override
			public void onWindowClosing() {
				onDisconnected(1);
			}
			
		};
		mfDisplayFrame.setVisible(true);

		mfNoteFrame = new NoteFrame(false, mfAddress) {
			
			
			@Override
			public void onMouseDragged(Line line) {
				try {
					ObjectOutputStream objectOutputStream = new ObjectOutputStream(mfSocket.getOutputStream());
					objectOutputStream.writeObject(line);
					objectOutputStream.flush();
				} catch (IOException e) {
					onDisconnected(3);
				}
			}

			@Override
			public void onWindowClosing() {
				onDisconnected(4);
			}
		};
		mfNoteFrame.setVisible(true);
	}
	
	private void onDisconnected(int from) {
		if (!mIsDisconnecting) {
			mIsDisconnecting = true;
			
			mfReceiverExecutor.shutdown();
			
			try {
				mfSocket.close();
			} catch (IOException e) {
			}
			
			if (mfDisplayFrame.isVisible()) {
				mfDisplayFrame.setVisible(false);
			}
			
			if (mfNoteFrame.isVisible()) {
				mfNoteFrame.setVisible(false);
			}
			
			new MenuFrame(mfUser32).setVisible(true);
		}
	}
}
