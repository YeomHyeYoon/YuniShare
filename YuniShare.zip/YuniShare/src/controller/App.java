package controller;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.WinDef.HWND;
import com.sun.jna.platform.win32.WinDef.RECT;
import com.sun.jna.platform.win32.WinUser;
import com.sun.jna.win32.StdCallLibrary;

import view.MenuFrame;

public class App {
	
	public static final int MAX_GUEST = 10;
	public static final String IMAGE_TYPE = "JPEG";

	public interface User32 extends StdCallLibrary {
		User32 INSTANCE = (User32) Native.load("user32", User32.class);

		int GetWindowTextA(HWND hWnd, byte[] lpString, int nMaxCount);
		
//		HWND GetForegroundWindow();

		boolean EnumWindows(WinUser.WNDENUMPROC lpEnumFunc, Pointer arg);
		long GetWindowLongA(HWND hwnd, int gwlWndproc);
		int GetWindowRect(HWND hWnd, RECT rect);
		boolean IsWindowVisible(HWND hWnd);
		int GetWindowTextLength(HWND hWnd);
		
		
	}
	
	public static void main(final String[] args) {
		final User32 user32 = User32.INSTANCE;
		new MenuFrame(user32).setVisible(true);
	}

}
